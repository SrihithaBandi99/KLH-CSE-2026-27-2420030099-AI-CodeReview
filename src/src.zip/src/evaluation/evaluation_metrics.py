from typing import Dict, List, Any

def calculate_precision(tp: int, fp: int) -> float:
    """Calculate precision securely handling zero denominator."""
    if tp + fp == 0:
        return 0.0
    return tp / (tp + fp)

def calculate_recall(tp: int, fn: int) -> float:
    """Calculate recall securely handling zero denominator."""
    if tp + fn == 0:
        return 0.0
    return tp / (tp + fn)

def calculate_f1(precision: float, recall: float) -> float:
    """Calculate F1 securely handling zero denominator."""
    if precision + recall == 0.0:
        return 0.0
    return 2 * (precision * recall) / (precision + recall)

def calculate_accuracy(correct: int, total: int) -> float:
    """Calculate accuracy securely handling zero denominator."""
    if total == 0:
        return 0.0
    return correct / total
