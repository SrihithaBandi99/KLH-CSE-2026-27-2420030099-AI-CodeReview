import os
import sys
from typing import Dict, Any, List

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.language_detector import LanguageDetector
from src.analyzers.pylint_analyzer import PylintAnalyzer
from src.analyzers.pmd_analyzer import PMDAnalyzer
from src.analyzers.eslint_analyzer import ESLintAnalyzer
from src.evaluation.evaluation_metrics import calculate_precision, calculate_recall, calculate_f1

class StaticAnalysisEvaluator:
    @staticmethod
    def evaluate(dataset: List[Dict[str, Any]]) -> Dict[str, Any]:
        results = {
            "python": {"tp": 0, "fp": 0, "fn": 0},
            "java": {"tp": 0, "fp": 0, "fn": 0},
            "javascript": {"tp": 0, "fp": 0, "fn": 0},
            "overall": {"tp": 0, "fp": 0, "fn": 0}
        }
        
        for item in dataset:
            lang = item["language"].lower()
            code = item["source_code"]
            expected = [e["rule"] for e in item.get("expected_static_issues", [])]
            
            # Detect
            detected_lang = LanguageDetector.detect_language(code)
            
            # Analyze
            actual_issues = []
            if detected_lang == "Python":
                actual_issues = PylintAnalyzer.analyze_code(code).get("issues", [])
            elif detected_lang == "Java":
                actual_issues = PMDAnalyzer.analyze_code(code).get("issues", [])
            elif detected_lang == "JavaScript":
                actual_issues = ESLintAnalyzer.analyze_code(code).get("issues", [])
                
            actual_rules = [i["rule"] for i in actual_issues]
            
            # Compare (Exact match on rule ID for simplicity)
            tp = sum(1 for r in actual_rules if r in expected)
            fp = sum(1 for r in actual_rules if r not in expected)
            fn = sum(1 for r in expected if r not in actual_rules)
            
            results[lang]["tp"] += tp
            results[lang]["fp"] += fp
            results[lang]["fn"] += fn
            
            results["overall"]["tp"] += tp
            results["overall"]["fp"] += fp
            results["overall"]["fn"] += fn

        # Calculate metrics
        for key in results:
            p = calculate_precision(results[key]["tp"], results[key]["fp"])
            r = calculate_recall(results[key]["tp"], results[key]["fn"])
            f1 = calculate_f1(p, r)
            results[key]["precision"] = p
            results[key]["recall"] = r
            results[key]["f1"] = f1
            
        return results
