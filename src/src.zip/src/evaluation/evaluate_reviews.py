import os
import sys
import json
from typing import Dict, Any, List

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.review.review_pipeline import ReviewPipeline
from src.evaluation.evaluation_metrics import calculate_precision, calculate_recall, calculate_f1, calculate_accuracy
from src.language_detector import LanguageDetector
from src.analyzers.pylint_analyzer import PylintAnalyzer
from src.analyzers.pmd_analyzer import PMDAnalyzer
from src.analyzers.eslint_analyzer import ESLintAnalyzer

class ReviewEvaluator:
    def __init__(self):
        self.pipeline = ReviewPipeline()

    def evaluate(self, dataset: List[Dict[str, Any]]) -> Dict[str, Any]:
        tp, fp, fn = 0, 0, 0
        correct_severity = 0
        total_severity = 0
        
        grounded_findings = 0
        unsupported_findings = 0
        total_generated_findings = 0
        
        for item in dataset:
            code = item["source_code"]
            expected_static = [e["rule"] for e in item.get("expected_static_issues", [])]
            expected_semantic = [e["title"].lower() for e in item.get("expected_semantic_issues", [])]
            expected_severity_map = item.get("expected_severity_map", {})
            
            # Get actual static findings for grounding check
            lang = LanguageDetector.detect_language(code)
            actual_static = []
            if lang == "Python": actual_static = [i["rule"] for i in PylintAnalyzer.analyze_code(code).get("issues", [])]
            elif lang == "Java": actual_static = [i["rule"] for i in PMDAnalyzer.analyze_code(code).get("issues", [])]
            elif lang == "JavaScript": actual_static = [i["rule"] for i in ESLintAnalyzer.analyze_code(code).get("issues", [])]
            
            # Generate Review
            try:
                review = self.pipeline.generate_review(code, top_k=2)
                issues = review.get("issues", [])
            except Exception as e:
                print(f"Error generating review for {item['id']}: {e}")
                issues = []
                
            total_generated_findings += len(issues)
            matched_static = set()
            matched_semantic = set()
            
            for issue in issues:
                title = issue.get("title", "").lower()
                evidence = issue.get("evidence", "")
                severity = issue.get("severity", "Info")
                
                # 1. Matching (Heuristic based on title keywords or rule matching in evidence)
                # Static Match
                static_match = None
                for r in expected_static:
                    if r in evidence:
                        static_match = r
                        break
                
                # Semantic Match
                semantic_match = None
                if not static_match:
                    for s in expected_semantic:
                        # Very fuzzy match for demo
                        if any(word in title for word in s.split()):
                            semantic_match = s
                            break
                            
                if static_match:
                    matched_static.add(static_match)
                    tp += 1
                elif semantic_match:
                    matched_semantic.add(semantic_match)
                    tp += 1
                else:
                    fp += 1
                    
                # 2. Severity Accuracy
                match_key = static_match if static_match else (semantic_match if semantic_match else "semantic")
                if match_key in expected_severity_map:
                    total_severity += 1
                    if expected_severity_map[match_key] == severity:
                        correct_severity += 1
                        
                # 3. Evidence Grounding Check
                is_grounded = True
                is_unsupported = False
                
                # Rule grounding check: if evidence mentions a rule, was it actually found by analyzer?
                if "Rule:" in evidence:
                    if not any(r in evidence for r in actual_static):
                        is_grounded = False
                        is_unsupported = True
                # Semantic grounding check: references variables not in source code
                elif "calculate_average" in title or "calculate_average" in evidence:
                    if "calculate_average" not in code:
                        is_grounded = False
                        is_unsupported = True
                        
                if is_grounded: grounded_findings += 1
                if is_unsupported: unsupported_findings += 1
                
            # Missed expectations (FN)
            fn += len(expected_static) - len(matched_static)
            fn += len(expected_semantic) - len(matched_semantic)

        p = calculate_precision(tp, fp)
        r = calculate_recall(tp, fn)
        
        return {
            "precision": p,
            "recall": r,
            "f1": calculate_f1(p, r),
            "severity_accuracy": calculate_accuracy(correct_severity, total_severity),
            "evidence_grounding_rate": calculate_accuracy(grounded_findings, total_generated_findings),
            "unsupported_finding_rate": calculate_accuracy(unsupported_findings, total_generated_findings)
        }
