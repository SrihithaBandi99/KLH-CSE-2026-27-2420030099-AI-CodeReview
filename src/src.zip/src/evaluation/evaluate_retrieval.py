import os
import sys
from typing import Dict, Any, List

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.retrieval.retriever import Retriever

class RetrievalEvaluator:
    @staticmethod
    def evaluate(dataset: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Evaluates retrieval.
        Note: Current evaluation uses the existing 8-vector prototype corpus.
        This is a known limitation. We do not evaluate against the full CodeSearchNet 
        corpus because it is not loaded locally. Recall metrics here are 
        demonstrative of the pipeline structure rather than statistically significant.
        """
        retriever = Retriever()
        
        # We will assume a mock relevant chunk logic for the prototype
        # If the language matches, we consider it a 'relevant' prototype hit.
        
        recall_at_1_hits = 0
        recall_at_2_hits = 0
        recall_at_3_hits = 0
        mrr_sum = 0.0
        
        total = len(dataset)
        
        for item in dataset:
            lang = item["language"]
            code = item["source_code"]
            
            results = retriever.retrieve(code, top_k=3)
            
            # For demonstration in prototype, a hit is simply finding a chunk of the same language
            hit_ranks = [i + 1 for i, res in enumerate(results) if res["language"].lower() == lang.lower()]
            
            if hit_ranks:
                first_hit = hit_ranks[0]
                if first_hit <= 1: recall_at_1_hits += 1
                if first_hit <= 2: recall_at_2_hits += 1
                if first_hit <= 3: recall_at_3_hits += 1
                mrr_sum += 1.0 / first_hit
                
        return {
            "recall_at_1": recall_at_1_hits / total if total > 0 else 0.0,
            "recall_at_2": recall_at_2_hits / total if total > 0 else 0.0,
            "recall_at_3": recall_at_3_hits / total if total > 0 else 0.0,
            "mrr": mrr_sum / total if total > 0 else 0.0,
            "note": "Evaluated against 8-chunk prototype corpus. Meaningful recall requires full dataset."
        }
