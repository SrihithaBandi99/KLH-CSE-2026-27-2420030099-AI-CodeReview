import os
import json
import sys

# Add project root to Python path
sys.path.insert(
    0,
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "../..")
    )
)

from src.evaluation.evaluation_dataset import EVALUATION_DATASET
from src.evaluation.evaluate_static_analysis import StaticAnalysisEvaluator
from src.evaluation.evaluate_retrieval import RetrievalEvaluator
from src.evaluation.evaluate_reviews import ReviewEvaluator


def run_evaluation():

    print("==================================================")
    print("PHASE 7 — EVALUATION")
    print("==================================================\n")

    # ==================================================
    # 1. STATIC ANALYSIS
    # ==================================================

    print("Evaluating Static Analysis...")

    static_results = StaticAnalysisEvaluator.evaluate(
        EVALUATION_DATASET
    )

    print("\nSTATIC ANALYSIS")

    for lang in ["python", "java", "javascript", "overall"]:

        tp = static_results[lang]["tp"]
        fp = static_results[lang]["fp"]
        fn = static_results[lang]["fn"]

        # Detection Accuracy
        accuracy = (
            tp / (tp + fp + fn)
            if (tp + fp + fn) > 0
            else 0.0
        )

        print(
            f"{lang.capitalize():12} "
            f"Precision: {static_results[lang]['precision']:.2f}"
        )

        print(
            f"{' ':12} "
            f"Recall:    {static_results[lang]['recall']:.2f}"
        )

        print(
            f"{' ':12} "
            f"F1:        {static_results[lang]['f1']:.2f}"
        )

        print(
            f"{' ':12} "
            f"Accuracy:  {accuracy:.2f}\n"
        )

        # Store accuracy in results
        static_results[lang]["accuracy"] = accuracy


    # ==================================================
    # 2. RETRIEVAL
    # ==================================================

    print("Evaluating Retrieval...")

    retrieval_results = RetrievalEvaluator.evaluate(
        EVALUATION_DATASET
    )

    print("\nRETRIEVAL")

    print(
        f"Recall@1: {retrieval_results['recall_at_1']:.2f}"
    )

    print(
        f"Recall@2: {retrieval_results['recall_at_2']:.2f}"
    )

    print(
        f"Recall@3: {retrieval_results['recall_at_3']:.2f}"
    )

    print(
        f"MRR:      {retrieval_results['mrr']:.2f}"
    )

    print(
        f"Note:     {retrieval_results['note']}\n"
    )


    # ==================================================
    # 3. REVIEW QUALITY
    # ==================================================

    print(
        "Evaluating Review Pipeline "
        "(Executing CodeLlama, this may take a few minutes)..."
    )

    rev_evaluator = ReviewEvaluator()

    review_results = rev_evaluator.evaluate(
        EVALUATION_DATASET
    )

    print("\nREVIEW QUALITY")

    print(
        f"Precision:                "
        f"{review_results['precision']:.2f}"
    )

    print(
        f"Recall:                   "
        f"{review_results['recall']:.2f}"
    )

    print(
        f"F1:                       "
        f"{review_results['f1']:.2f}\n"
    )

    print(
        f"Severity Accuracy:        "
        f"{review_results['severity_accuracy']:.2f}"
    )

    print(
        f"Evidence Grounding Rate:  "
        f"{review_results['evidence_grounding_rate']:.2f}"
    )

    print(
        f"Unsupported Finding Rate: "
        f"{review_results['unsupported_finding_rate']:.2f}\n"
    )


    # ==================================================
    # 4. SAVE RESULTS
    # ==================================================

    final_results = {
        "static_analysis": static_results,
        "retrieval": retrieval_results,
        "review": review_results
    }

    out_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            "../../evaluation_results"
        )
    )

    os.makedirs(
        out_dir,
        exist_ok=True
    )


    # Save JSON results
    json_path = os.path.join(
        out_dir,
        "evaluation_results.json"
    )

    with open(
        json_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            final_results,
            f,
            indent=2
        )


    # Save text report
    txt_path = os.path.join(
        out_dir,
        "evaluation_report.txt"
    )

    with open(
        txt_path,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(
            "PHASE 7 EVALUATION REPORT\n"
        )

        f.write(
            json.dumps(
                final_results,
                indent=2
            )
        )


    # ==================================================
    # 5. COMPLETION MESSAGE
    # ==================================================

    print("==================================================")
    print("PHASE 7 COMPLETE")
    print("==================================================")

    print(
        f"Results saved to: {out_dir}"
    )


if __name__ == "__main__":
    run_evaluation()