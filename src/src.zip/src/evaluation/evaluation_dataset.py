"""
Small, manually annotated evaluation dataset representing Python, Java, and JavaScript files.
"""

EVALUATION_DATASET = [
    {
        "id": "py_01",
        "language": "Python",
        "source_code": "# This function should return the sum of a and b.\ndef add(a, b):\n    return a - b\n",
        # We expect a missing docstring from pylint.
        "expected_static_issues": [
            {"rule": "C0116"} # missing-function-docstring
        ],
        # We assume semantic behavior is explicit and expected to be addition based on name context.
        "expected_semantic_issues": [
            {"title": "Incorrect function behavior"} 
        ],
        "expected_severity_map": {
            "C0116": "Info", 
            "semantic": "High"
        }
    },
    {
        "id": "java_01",
        "language": "Java",
        "source_code": "public class Auth {\n    public boolean login(String u, String p) {\n        if (p == \"12345\") { return true; }\n        return false;\n    }\n}\n",
        "expected_static_issues": [
            {"rule": "UseEqualsToCompareStrings"}
        ],
        "expected_semantic_issues": [
            {"title": "Insecure password storage/comparison"}
        ],
        "expected_severity_map": {
            "UseEqualsToCompareStrings": "High",
            "semantic": "Critical"
        }
    },
    {
        "id": "js_01",
        "language": "JavaScript",
        "source_code": "function checkUser(u, p) {\n    var secret = '12345';\n    if (p == secret) {\n        console.log('OK')\n    }\n}\n",
        "expected_static_issues": [
            {"rule": "no-var"},
            {"rule": "eqeqeq"},
            {"rule": "semi"}
        ],
        "expected_semantic_issues": [
            {"title": "Insecure password storage"}
        ],
        "expected_severity_map": {
            "no-var": "Low",
            "eqeqeq": "Medium",
            "semi": "Low",
            "semantic": "High"
        }
    }
]
