import torch
from transformers import AutoTokenizer, AutoModel
import numpy as np
from typing import List

class CodeBERTEmbeddings:
    """
    Generates semantic embeddings for code chunks using microsoft/codebert-base.
    Optimized for CPU usage on a 16GB RAM machine.
    """
    
    def __init__(self, model_name: str = "microsoft/codebert-base", max_length: int = 512, batch_size: int = 4):
        self.model_name = model_name
        self.max_length = max_length
        self.batch_size = batch_size
        self.device = torch.device("cpu")
        
        print(f"Loading {model_name} onto {self.device}...")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name).to(self.device)
        self.model.eval() # Ensure inference mode
        
        # Get embedding dimension
        self.dimension = self.model.config.hidden_size
        print(f"Model loaded. Embedding dimension: {self.dimension}")

    def generate_embeddings(self, codes: List[str]) -> np.ndarray:
        """
        Generates embeddings for a list of code snippets.
        Processes in small batches to save memory.
        Uses mean pooling over token embeddings.
        Normalizes output for FAISS Inner Product search.
        """
        if not codes:
            return np.empty((0, self.dimension), dtype=np.float32)
            
        all_embeddings = []
        
        with torch.no_grad():
            for i in range(0, len(codes), self.batch_size):
                batch_codes = codes[i:i + self.batch_size]
                
                # Tokenize
                inputs = self.tokenizer(
                    batch_codes, 
                    padding=True, 
                    truncation=True, 
                    max_length=self.max_length, 
                    return_tensors="pt"
                ).to(self.device)
                
                # Forward pass
                outputs = self.model(**inputs)
                
                # Mean pooling: average over the sequence length, considering attention mask
                attention_mask = inputs['attention_mask'].unsqueeze(-1).expand(outputs.last_hidden_state.size()).float()
                sum_embeddings = torch.sum(outputs.last_hidden_state * attention_mask, 1)
                sum_mask = torch.clamp(attention_mask.sum(1), min=1e-9)
                mean_pooled = sum_embeddings / sum_mask
                
                # Normalize for FAISS Inner Product (Cosine Similarity)
                normalized = torch.nn.functional.normalize(mean_pooled, p=2, dim=1)
                
                all_embeddings.append(normalized.cpu().numpy())
                
        # Concatenate all batches
        return np.vstack(all_embeddings).astype(np.float32)
