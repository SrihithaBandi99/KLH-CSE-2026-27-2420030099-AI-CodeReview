
from pathlib import Path
from llama_cpp import Llama # type: ignore


# ============================================================
# CODELLAMA MODEL PATH
# ============================================================

MODEL_PATH = (
    Path(__file__).resolve().parents[2]
    / "models"
    / "codellama"
    / "codellama-7b-instruct.Q4_K_M.gguf"
)


# ============================================================
# LOAD CODELLAMA
# ============================================================

def load_model():

    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"\nCodeLlama model not found!\n"
            f"Expected location:\n{MODEL_PATH}\n"
        )

    print("\nLoading CodeLlama...")
    print(f"Model path: {MODEL_PATH}")

    model = Llama(
        model_path=str(MODEL_PATH),
        n_ctx=4096,
        n_threads=8,
        n_gpu_layers=0,
        verbose=False
    )

    print("CodeLlama loaded successfully!")

    return model


# ============================================================
# CODE REVIEW FUNCTION
# ============================================================

def review_code(model, code):

    prompt = f"""
[INST]
You are an expert code reviewer.

Review the following Python code.

Find the bug or problem.

Explain:
1. What is wrong?
2. Why is it wrong?
3. How can it be fixed?

Give a short and beginner-friendly answer.

Python code:

```python
{code}
```
[/INST]
"""

    response = model(
        prompt,
        max_tokens=512,
        temperature=0.1,
        stop=["</s>"]
    )

    return response["choices"][0]["text"].strip()


# ============================================================
# MAIN TEST
# ============================================================

def main():

    print("=" * 60)
    print("PHASE 1 - CODELLAMA INFERENCE TEST")
    print("=" * 60)

    # Load CodeLlama
    model = load_model()

    # Intentionally buggy Python code
    test_code = """
def add(a, b):
    return a - b
"""

    print("\nTest Python Code:")
    print(test_code)

    print("\nGenerating Code Review...")
    print("-" * 60)

    # Ask CodeLlama to review the code
    result = review_code(model, test_code)

    print("\nCODELLAMA REVIEW:")
    print(result)

    print("-" * 60)
    print("Phase 1 CodeLlama inference test completed.")


# ============================================================
# PROGRAM START
# ============================================================

if __name__ == "__main__":
    main()
