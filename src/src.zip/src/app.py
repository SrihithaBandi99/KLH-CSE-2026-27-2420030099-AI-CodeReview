import os
import sys
import streamlit as st

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.review.review_pipeline import ReviewPipeline

# =====================================================================
# UI CONFIGURATION
# =====================================================================
st.set_page_config(
    page_title="AI Code Review Copilot",
    page_icon="💻",
    layout="wide",
    initial_sidebar_state="expanded"
)

# =====================================================================
# STATE MANAGEMENT & CACHING
# =====================================================================
@st.cache_resource(show_spinner="Loading AI Models (CodeBERT & CodeLlama) into memory. This takes a moment...")
def load_pipeline():
    """Loads the pipeline only once to prevent OOM/slow reloads."""
    return ReviewPipeline()

# =====================================================================
# UTILITY FUNCTIONS
# =====================================================================
def get_severity_color(severity):
    colors = {
        "Critical": "🔴",
        "High": "🟠",
        "Medium": "🟡",
        "Low": "🔵",
        "Info": "⚪"
    }
    return colors.get(severity, "⚪")

def count_severities(issues):
    counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
    for issue in issues:
        sev = issue.get("severity", "Info")
        if sev in counts:
            counts[sev] += 1
    return counts

# =====================================================================
# MAIN APP
# =====================================================================
def main():
    st.title("💻 Context-Aware Automated Code Review Copilot")
    st.markdown("Powered by **CodeLlama 7B**, **CodeBERT**, and **FAISS**.")
    
    # Initialize Pipeline
    try:
        pipeline = load_pipeline()
    except Exception as e:
        st.error(f"Failed to load AI Pipeline: {e}")
        return

    # --- Sidebar ---
    with st.sidebar:
        st.header("Settings")
        st.info("The language will be auto-detected, but you can upload a file or paste your code directly.")
        
        uploaded_file = st.file_uploader("Upload Source Code File", type=["py", "java", "js"])
    
    # --- Main Input Area ---
    st.subheader("Source Code Input")
    
    # Handle File Upload
    default_code = ""
    if uploaded_file is not None:
        try:
            default_code = uploaded_file.getvalue().decode("utf-8")
        except Exception:
            st.error("Failed to read the uploaded file.")
            
    code_input = st.text_area("Paste code here:", value=default_code, height=300)
    
    if st.button("🚀 Review Code", type="primary"):
        if not code_input.strip():
            st.warning("Please provide source code to review.")
            return
            
        with st.spinner("Analyzing code, retrieving context, and generating review..."):
            try:
                # Execute Pipeline
                review_result = pipeline.generate_review(code_input, top_k=3)
                
                # --- Output Rendering ---
                st.success(f"Review Complete! Detected Language: **{review_result.get('language', 'Unknown')}**")
                
                issues = review_result.get("issues", [])
                
                # Render Metrics Summary
                if not issues:
                    st.balloons()
                    st.info("No issues found! Your code looks great.")
                else:
                    st.subheader("Review Summary")
                    counts = count_severities(issues)
                    
                    col1, col2, col3, col4, col5 = st.columns(5)
                    col1.metric("Total Issues", len(issues))
                    col2.metric("Critical", counts["Critical"])
                    col3.metric("High", counts["High"])
                    col4.metric("Medium", counts["Medium"])
                    col5.metric("Low", counts["Low"])
                    
                    st.divider()
                    
                    # Render Issues
                    st.subheader("Detailed Findings")
                    for i, issue in enumerate(issues):
                        sev = issue.get("severity", "Info")
                        icon = get_severity_color(sev)
                        title = issue.get("title", "Unknown Issue")
                        confidence = issue.get("confidence", 0.0)
                        
                        with st.expander(f"{icon} {sev}: {title} (Confidence: {confidence:.2f})", expanded=(sev in ["Critical", "High"])):
                            st.markdown(f"**Explanation:**\n{issue.get('explanation', '')}")
                            st.markdown(f"**Suggested Fix:**\n{issue.get('suggested_fix', '')}")
                            st.info(f"**Evidence:**\n{issue.get('evidence', '')}")
                            
            except Exception as e:
                st.error("An error occurred during the review process. Please check the logs.")
                import traceback
                traceback.print_exc()

if __name__ == "__main__":
    main()
