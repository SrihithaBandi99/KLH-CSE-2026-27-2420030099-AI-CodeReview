from typing import List, Dict, Any

class PromptBuilder:
    """
    Constructs the final RAG prompt for CodeLlama Instruct.
    Combines source code, static analysis findings, retrieved context,
    and structured output instructions.
    """
    
    @staticmethod
    def build_rag_prompt(language: str, source_code: str, static_findings: List[Dict[str, Any]], retrieved_context: List[Dict[str, Any]]) -> str:
        """Builds the comprehensive RAG prompt."""
        
        # 1. Format Static Findings
        findings_text = ""
        if static_findings:
            findings_text += "=== STATIC ANALYSIS FINDINGS ===\n"
            for f in static_findings:
                findings_text += f"- Line {f.get('line', '?')} [{f.get('severity', 'info').upper()}]: {f.get('message', '')} (Rule: {f.get('rule', '')} via {f.get('tool', 'analyzer')})\n"
        else:
            findings_text += "=== STATIC ANALYSIS FINDINGS ===\nNone.\n"
            
        # 2. Format Retrieved Context
        context_text = ""
        if retrieved_context:
            context_text += "=== RETRIEVED REFERENCE CONTEXT ===\n"
            for i, ctx in enumerate(retrieved_context):
                context_text += f"--- CONTEXT #{i+1} ---\n"
                context_text += f"Source: {ctx.get('source', 'unknown')} | Similarity: {ctx.get('score', 0):.2f}\n"
                context_text += f"```{ctx.get('language', '').lower()}\n{ctx.get('code', '')}\n```\n\n"
        else:
            context_text += "=== RETRIEVED REFERENCE CONTEXT ===\nNone available.\n"
            
        # 3. Construct Final Prompt with CodeLlama Instruct tags [INST] ... [/INST]
        prompt = f"""[INST]
You are an expert software code reviewer.

LANGUAGE:
{language}

=== SUBMITTED SOURCE CODE ===
```{language.lower()}
{source_code}
```

{findings_text}
{context_text}
=== REVIEW INSTRUCTIONS ===
The final review must be based primarily on SUBMITTED SOURCE CODE.
Identify bugs, security issues, code-quality problems, or logic errors.

CRITICAL RAG GROUNDING RULES:
- Review ONLY the SUBMITTED SOURCE CODE for actual findings.
- RETRIEVED REFERENCE CONTEXT may help explain or suggest best practices. It is NOT evidence about the submitted source code.
- Never treat retrieved code as part of the submitted code.
- Never use retrieved context as evidence.
- The model must NEVER copy a function name, variable name, API, vulnerability, or behavior from retrieved context and claim that it exists in the submitted source code.
- Every evidence statement must refer to the submitted source code or an actual static-analysis finding.
- Do not invent line numbers.
- If static analysis does not support a claim, do not attach a static-analysis rule to that claim. Do not claim a naming rule proves a security vulnerability.
- NEVER use C0114, C0116, C0304, C0103, or any other unrelated style rule as evidence for a security or semantic finding.

EVIDENCE GENERATION RULES:
1. Every static-analysis evidence item MUST correspond to the exact claim being made.
2. If the finding comes directly from Pylint/PMD/ESLint, use the exact matching analyzer finding.
   Format: "Line X: <actual analyzer message> (Rule: <actual rule> via <tool>)"
3. If the finding is a semantic observation by you, do NOT attach an unrelated static-analysis rule.
   Format: "Line X: <direct observation from submitted source code>"
4. NEVER invent a rule to support a semantic finding. Static and semantic evidence must remain clearly separated.

EXAMPLE OF CORRECT SEMANTIC EVIDENCE:
"evidence": "Line 2: The code executes `return a - b` which performs subtraction rather than addition."
EXAMPLE OF INCORRECT SEMANTIC EVIDENCE:
"evidence": "Line 1: Missing function docstring (Rule: C0116 via pylint)" <-- DO NOT DO THIS FOR LOGIC ERRORS.

- If there are no issues in the SUBMITTED SOURCE CODE, return an empty issues list.

OUTPUT FORMAT:
You MUST return ONLY valid JSON in the exact format below. Do not add conversational text.

{{
    "language": "{language}",
    "issues": [
        {{
            "title": "Short issue title",
            "severity": "Critical|High|Medium|Low|Info",
            "explanation": "Why this is an issue.",
            "suggested_fix": "How to fix it.",
            "evidence": "Supporting evidence from code lines or static analysis.",
            "confidence": 0.95
        }}
    ]
}}
[/INST]"""
        return prompt
