import json
import re
from typing import Dict, Any

class OutputParser:
    """
    Parses and validates the raw text output from CodeLlama into a structured JSON dictionary.
    Handles common LLM artifacts like markdown fences and conversational prefixes.
    """
    
    ALLOWED_SEVERITIES = {"Critical", "High", "Medium", "Low", "Info"}
    
    @staticmethod
    def parse_review_json(text: str) -> Dict[str, Any]:
        """Extracts JSON from LLM output and validates it."""
        print("DEBUG: PARSER START")
        print("DEBUG: Raw text length =", len(text) if text else 0)
        
        if not text:
            print("DEBUG: text is empty/None")
            return OutputParser._create_fallback("Empty output", "")
            
        text = text.strip()
        print("DEBUG: After strip length =", len(text))
        
        # 1. Attempt to extract JSON from markdown fences
        json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
        if json_match:
            print("DEBUG: Matched markdown fence.")
            json_str = json_match.group(1)
        else:
            print("DEBUG: No markdown fence found. Using fallback curly brace extraction.")
            # 2. Fallback: find the first { and last }
            start = text.find('{')
            end = text.rfind('}')
            print(f"DEBUG: found {{ at {start}, }} at {end}")
            if start != -1 and end != -1 and end > start:
                json_str = text[start:end+1]
            else:
                print("DEBUG: Failed to extract any JSON blocks.")
                return OutputParser._create_fallback("Failed to extract JSON from model output.", text)
                
        # 3. Parse JSON
        print("DEBUG: About to json.loads()")
        try:
            parsed = json.loads(json_str)
            print("DEBUG: json.loads() successful")
        except json.JSONDecodeError as e:
            print(f"DEBUG: json.loads() failed: {e}")
            return OutputParser._create_fallback(f"JSON Parsing Error: {e}", json_str)
            
        # 4. Validate Schema & Fix Severities
        print("DEBUG: Validating schema...")
        if "issues" not in parsed or not isinstance(parsed["issues"], list):
            parsed["issues"] = []
            
        for issue in parsed["issues"]:
            severity = issue.get("severity", "Info")
            # Normalize severity capitalization
            severity_cap = str(severity).capitalize()
            if severity_cap not in OutputParser.ALLOWED_SEVERITIES:
                severity_cap = "Info"
            issue["severity"] = severity_cap
            
            # Ensure required fields exist
            issue.setdefault("title", "Unknown Issue")
            issue.setdefault("explanation", "No explanation provided.")
            issue.setdefault("suggested_fix", "No fix suggested.")
            issue.setdefault("evidence", "No evidence provided.")
            
            # Ensure confidence is a float
            try:
                issue["confidence"] = float(issue.get("confidence", 0.5))
            except ValueError:
                issue["confidence"] = 0.5
                
        print("DEBUG: Parser finished successfully.")
        return parsed

    @staticmethod
    def _create_fallback(error_msg: str, raw_output: str) -> Dict[str, Any]:
        """Returns a fallback dictionary when parsing fails completely."""
        return {
            "language": "Unknown",
            "error": error_msg,
            "raw_output": raw_output[:500] + "..." if len(raw_output) > 500 else raw_output,
            "issues": [
                {
                    "title": "Output Parsing Failure",
                    "severity": "High",
                    "explanation": "The AI model produced malformed JSON output that could not be parsed.",
                    "suggested_fix": "Retry the generation or adjust the prompt.",
                    "evidence": "N/A",
                    "confidence": 1.0
                }
            ]
        }
