from typing import Dict, Any
import re

class SeverityClassifier:
    """
    Deterministic severity classifier that maps validated evidence and rules
    to strict severity levels (Critical, High, Medium, Low, Info).
    """
    
    VALID_SEVERITIES = {"Critical", "High", "Medium", "Low", "Info"}
    
    STATIC_RULES_MAPPING = {
        "C0116": "Info",
        "no-var": "Low",
        "semi": "Low",
        "eqeqeq": "Medium",
        "UseEqualsToCompareStrings": "High"
    }
    
    @staticmethod
    def classify(issue: Dict[str, Any]) -> str:
        evidence = issue.get("evidence", "")
        title = issue.get("title", "").lower()
        explanation = issue.get("explanation", "").lower()
        original_severity = issue.get("severity", "Info")
        
        # 1. Static Rule Evidence Override
        # If evidence explicitly states "Rule: X via Y", use strict deterministic mapping.
        rule_match = re.search(r"Rule:\s*([^\s\)]+)", evidence)
        if rule_match:
            rule_id = rule_match.group(1)
            if rule_id in SeverityClassifier.STATIC_RULES_MAPPING:
                return SeverityClassifier.STATIC_RULES_MAPPING[rule_id]
        
        # 2. Semantic Issue Keyword Matching
        full_text = f"{title} {explanation} {evidence.lower()}"
        
        # Critical checks
        if any(keyword in full_text for keyword in [
            "hardcoded password", "exposed secret", "credential exposure",
            "authentication bypass", "sql injection", "command injection",
            "arbitrary code execution", "severe security vulnerability"
        ]):
            return "Critical"
            
        # High checks
        if any(keyword in full_text for keyword in [
            "division by zero", "null dereference", "none dereference",
            "incorrect behavior", "incorrect calculation", "resource leak",
            "insecure authentication", "serious correctness", "incorrect function behavior",
            "incorrect" # General semantic fallback for incorrectly implemented functions
        ]):
            return "High"
            
        # Medium checks
        if any(keyword in full_text for keyword in [
            "risky type handling", "potentially unsafe comparison",
            "maintainability issue"
        ]):
            return "Medium"
            
        # Low checks
        if any(keyword in full_text for keyword in [
            "style problem", "readability problem", "minor maintainability"
        ]):
            return "Low"
            
        # Info checks
        if any(keyword in full_text for keyword in [
            "documentation-only", "informational"
        ]):
            return "Info"
            
        # 3. Fallback normalization
        if original_severity in SeverityClassifier.VALID_SEVERITIES:
            return original_severity
            
        # Safe fallback for arbitrary hallucinated severities
        return "Info"
