import os
import sys
from typing import Dict, Any

# Ensure we can import from project root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.language_detector import LanguageDetector
from src.analyzers.pylint_analyzer import PylintAnalyzer
from src.analyzers.pmd_analyzer import PMDAnalyzer
from src.analyzers.eslint_analyzer import ESLintAnalyzer
from src.retrieval.retriever import Retriever
from src.prompting.prompt_builder import PromptBuilder
from src.review.output_parser import OutputParser
from src.review.severity_classifier import SeverityClassifier

# Import the existing CodeLlama client loader
from src.llm.codellama_client import load_model

class ReviewPipeline:
    """
    Orchestrates the entire Phase 5 RAG pipeline:
    Source -> Language Det -> Static Analysis -> Retrieval -> Prompt -> CodeLlama -> Output
    """
    def __init__(self):
        print("\nInitializing RAG Review Pipeline...")
        # 1. Initialize Retriever (loads CodeBERT + FAISS)
        self.retriever = Retriever()
        
        # 2. Initialize LLM (loads CodeLlama GGUF)
        self.llm = load_model()
        print("Review Pipeline Initialization Complete!\n")

    def analyze_source(self, code: str, language: str) -> Dict[str, Any]:
        """Routes code to the correct static analyzer."""
        if language == "Python":
            return PylintAnalyzer.analyze_code(code)
        elif language == "Java":
            return PMDAnalyzer.analyze_code(code)
        elif language == "JavaScript":
            return ESLintAnalyzer.analyze_code(code)
        else:
            return {"language": language, "issues": []}

    def generate_review(self, source_code: str, top_k: int = 3) -> Dict[str, Any]:
        """Main orchestrator function."""
        # 1. Detect Language
        language = LanguageDetector.detect_language(source_code)
        print(f"Detected Language: {language}")
        
        # 2. Static Analysis
        print("Running Static Analysis...")
        static_results = self.analyze_source(source_code, language)
        static_findings = static_results.get("issues", [])
        print(f"Static Analysis found {len(static_findings)} issues.")
        
        # 3. Retrieval
        print("Retrieving Contextual Code...")
        try:
            retrieved_context = self.retriever.retrieve(source_code, top_k=top_k, language=language)
            print(f"Retrieved {len(retrieved_context)} context chunks.")
        except ValueError as e:
            print(f"Retrieval skipped/failed: {e}")
            retrieved_context = []
            
        # 4. Prompt Construction
        print("Building RAG Prompt...")
        prompt = PromptBuilder.build_rag_prompt(language, source_code, static_findings, retrieved_context)
        
        # 5. LLM Inference
        print("DEBUG A: About to call CodeLlama")
        print("DEBUG: Prompt length =", len(prompt))
        try:
            response = self.llm(
                prompt,
                max_tokens=1024,
                temperature=0.1,
                stop=["[/INST]", "</s>"]
            )
            print("DEBUG B: CodeLlama call returned")
            print("DEBUG C: response type =", type(response))
            if isinstance(response, dict):
                print("DEBUG: response keys =", response.keys())
            
            raw_output = response["choices"][0]["text"] if response and "choices" in response else ""
            print("DEBUG D: raw_output length =", len(raw_output) if raw_output else 0)
        except BaseException as e:
            import traceback
            print("========== CODELLAMA EXCEPTION ==========")
            print(type(e).__name__, ":", str(e))
            traceback.print_exc()
            raise
        
        # 6. Parse Output
        print("Parsing LLM Output...")
        print("DEBUG E: About to parse response")
        try:
            final_review = OutputParser.parse_review_json(raw_output)
            print("DEBUG F: PARSER FINISHED")
        except BaseException as e:
            import traceback
            print("========== PARSER EXCEPTION ==========")
            print(type(e).__name__, ":", str(e))
            traceback.print_exc()
            raise
            
        # 7. Deterministic Severity Classification
        if "issues" in final_review and isinstance(final_review["issues"], list):
            for issue in final_review["issues"]:
                issue["severity"] = SeverityClassifier.classify(issue)
        
        return final_review
