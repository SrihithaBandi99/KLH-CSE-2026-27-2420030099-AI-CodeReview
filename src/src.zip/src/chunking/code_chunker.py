import re
from typing import List, Dict, Any
import hashlib

class CodeChunker:
    """
    A simple, language-aware code chunker that splits source files into
    meaningful chunks (functions, classes) without requiring full AST parsing.
    """
    
    @staticmethod
    def _generate_chunk_id(source: str, start_line: int, end_line: int) -> str:
        """Generates a unique ID for a chunk."""
        unique_str = f"{source}:{start_line}:{end_line}"
        return hashlib.md5(unique_str.encode('utf-8')).hexdigest()[:12]

    @staticmethod
    def chunk_python(code: str, source: str) -> List[Dict[str, Any]]:
        """Simple chunking for Python based on indentation and keywords."""
        chunks = []
        lines = code.split('\n')
        
        current_chunk = []
        start_line = 1
        in_block = False
        block_indent = 0
        
        for i, line in enumerate(lines):
            line_num = i + 1
            stripped = line.strip()
            
            # Detect start of a function or class
            if (stripped.startswith("def ") or stripped.startswith("class ")) and line.endswith(":"):
                if current_chunk and not in_block:
                    # Save previous global chunk if it exists
                    chunks.append(CodeChunker._create_chunk_dict("Python", source, current_chunk, start_line, line_num - 1))
                    current_chunk = []
                
                if current_chunk and in_block:
                    chunks.append(CodeChunker._create_chunk_dict("Python", source, current_chunk, start_line, line_num - 1))
                    current_chunk = []
                    
                in_block = True
                start_line = line_num
                # Find indentation level
                block_indent = len(line) - len(line.lstrip())
                
            elif in_block and stripped != "":
                # Check if we exited the block
                current_indent = len(line) - len(line.lstrip())
                if current_indent <= block_indent and not line.startswith(")"):
                    # Block ended
                    in_block = False
                    chunks.append(CodeChunker._create_chunk_dict("Python", source, current_chunk, start_line, line_num - 1))
                    current_chunk = []
                    start_line = line_num
                    
            current_chunk.append(line)
            
        if current_chunk:
            chunks.append(CodeChunker._create_chunk_dict("Python", source, current_chunk, start_line, len(lines)))
            
        return [c for c in chunks if c["code"].strip()]

    @staticmethod
    def chunk_java_or_js(code: str, source: str, language: str) -> List[Dict[str, Any]]:
        """Simple chunking for Java/JS based on curly braces."""
        chunks = []
        lines = code.split('\n')
        
        current_chunk = []
        start_line = 1
        brace_count = 0
        in_block = False
        
        for i, line in enumerate(lines):
            line_num = i + 1
            stripped = line.strip()
            
            # Simple heuristic for start of method/class/function
            if not in_block and ("{" in line) and (
                "class " in line or "public " in line or "private " in line or 
                "function " in line or "=>" in line or "=" in line or 
                line.endswith("{")):
                
                if current_chunk:
                    chunks.append(CodeChunker._create_chunk_dict(language, source, current_chunk, start_line, line_num - 1))
                    current_chunk = []
                
                in_block = True
                start_line = line_num
                
            brace_count += line.count("{")
            brace_count -= line.count("}")
            
            current_chunk.append(line)
            
            if in_block and brace_count == 0:
                # Block ended
                in_block = False
                chunks.append(CodeChunker._create_chunk_dict(language, source, current_chunk, start_line, line_num))
                current_chunk = []
                start_line = line_num + 1
                
        if current_chunk:
            chunks.append(CodeChunker._create_chunk_dict(language, source, current_chunk, start_line, len(lines)))
            
        return [c for c in chunks if c["code"].strip()]

    @staticmethod
    def _create_chunk_dict(language: str, source: str, lines: List[str], start: int, end: int) -> Dict[str, Any]:
        code = "\n".join(lines).strip()
        return {
            "chunk_id": CodeChunker._generate_chunk_id(source, start, end),
            "language": language,
            "code": code,
            "source": source,
            "start_line": start,
            "end_line": end
        }

    @classmethod
    def chunk_code(cls, code: str, language: str, source: str = "unknown") -> List[Dict[str, Any]]:
        """Main entry point for chunking."""
        if language == "Python":
            return cls.chunk_python(code, source)
        elif language in ["Java", "JavaScript"]:
            return cls.chunk_java_or_js(code, source, language)
        else:
            # Fallback for unknown languages: return as one chunk
            return [cls._create_chunk_dict(language, source, code.split('\n'), 1, len(code.split('\n')))]
