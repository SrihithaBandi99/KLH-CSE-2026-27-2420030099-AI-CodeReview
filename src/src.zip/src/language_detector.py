import os
import re

class LanguageDetector:
    """
    Detects the programming language of a given code snippet or file.
    Supports Python, Java, and JavaScript.
    """

    SUPPORTED_LANGUAGES = {
        "Python": [".py"],
        "Java": [".java"],
        "JavaScript": [".js", ".jsx"]
    }

    @staticmethod
    def detect_from_filename(filename: str) -> str:
        """Detect language based on file extension."""
        _, ext = os.path.splitext(filename)
        ext = ext.lower()
        for lang, extensions in LanguageDetector.SUPPORTED_LANGUAGES.items():
            if ext in extensions:
                return lang
        return "Unknown"

    @staticmethod
    def detect_from_code(code: str) -> str:
        """
        Fallback heuristic to detect language from code snippets if filename is not provided.
        Uses simple keyword matching suitable for our prototype.
        """
        # Python heuristics
        if re.search(r'\bdef\s+\w+\s*\(', code) or re.search(r'\bimport\s+[\w\.]+', code) and not ';' in code:
            return "Python"
        
        # Java heuristics
        if re.search(r'\bpublic\s+class\s+\w+', code) or re.search(r'\bSystem\.out\.println\s*\(', code):
            return "Java"
            
        # JavaScript heuristics
        if re.search(r'\bconst\s+\w+\s*=', code) or re.search(r'\blet\s+\w+\s*=', code) or re.search(r'\bconsole\.log\s*\(', code) or re.search(r'\bfunction\s*\w*\s*\(', code):
            return "JavaScript"
            
        return "Unknown"

    @classmethod
    def detect_language(cls, code: str, filename: str = None) -> str:
        """
        Main method to detect language. Prioritizes filename if provided.
        """
        if filename:
            lang = cls.detect_from_filename(filename)
            if lang != "Unknown":
                return lang
                
        return cls.detect_from_code(code)

if __name__ == "__main__":
    # Simple tests
    python_code = "def hello():\n    print('world')"
    java_code = "public class Hello {\n    public static void main(String[] args) {\n        System.out.println(\"world\");\n    }\n}"
    js_code = "const hello = () => {\n    console.log('world');\n}"

    print(f"File detection (test.py): {LanguageDetector.detect_language('', 'test.py')}")
    print(f"File detection (Test.java): {LanguageDetector.detect_language('', 'Test.java')}")
    print(f"File detection (app.js): {LanguageDetector.detect_language('', 'app.js')}")
    
    print(f"Snippet detection (Python): {LanguageDetector.detect_language(python_code)}")
    print(f"Snippet detection (Java): {LanguageDetector.detect_language(java_code)}")
    print(f"Snippet detection (JavaScript): {LanguageDetector.detect_language(js_code)}")
