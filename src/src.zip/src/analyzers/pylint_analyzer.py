import json
import subprocess
import tempfile
import os
from typing import Dict, Any

class PylintAnalyzer:
    """
    Runs Pylint on Python source code or files and normalizes the output
    into a standardized format.
    """
    
    @staticmethod
    def analyze_file(filepath: str) -> Dict[str, Any]:
        """Runs Pylint on a given file path."""
        if not os.path.exists(filepath):
            return {"language": "Python", "error": f"File not found: {filepath}", "issues": []}

        import sys
        try:
            # Run pylint and output in JSON format using python -m pylint
            result = subprocess.run(
                [sys.executable, "-m", "pylint", "--output-format=json", filepath],
                capture_output=True,
                text=True
            )
            
            # Pylint exits with non-zero if issues are found, which is expected.
            # We just care about parsing the stdout.
            if not result.stdout.strip():
                return {"language": "Python", "issues": []}
                
            pylint_output = json.loads(result.stdout)
            
            normalized_issues = []
            for issue in pylint_output:
                normalized_issues.append({
                    "line": issue.get("line", 0),
                    "rule": issue.get("message-id", ""),
                    "message": issue.get("message", ""),
                    "severity": issue.get("type", "unknown"),
                    "tool": "pylint"
                })
                
            return {
                "language": "Python",
                "issues": normalized_issues
            }

        except json.JSONDecodeError as e:
            return {"language": "Python", "error": f"Failed to parse Pylint output: {str(e)}", "issues": []}
        except Exception as e:
            return {"language": "Python", "error": f"Pylint execution failed: {str(e)}", "issues": []}

    @staticmethod
    def analyze_code(code: str) -> Dict[str, Any]:
        """Runs Pylint on a raw code snippet by using a temporary file."""
        # Use a temporary file to run pylint on raw string
        fd, temp_path = tempfile.mkstemp(suffix=".py")
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(code)
            return PylintAnalyzer.analyze_file(temp_path)
        finally:
            # Clean up the temporary file
            if os.path.exists(temp_path):
                os.remove(temp_path)

if __name__ == "__main__":
    # Test with intentionally problematic Python code
    problematic_code = """
def my_function(a,b):
  # missing docstring
  X = a+b # bad variable name and spacing
  return X
"""
    
    print("Testing PylintAnalyzer with problematic code snippet...")
    result = PylintAnalyzer.analyze_code(problematic_code)
    
    print("\nResult:")
    print(json.dumps(result, indent=4))
