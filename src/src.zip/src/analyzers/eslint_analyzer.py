import json
import subprocess
import tempfile
import os
import shutil
from typing import Dict, Any

class ESLintAnalyzer:
    """
    Runs ESLint on JavaScript source code or files and normalizes the output.
    """
    
    @staticmethod
    def is_available() -> bool:
        """Check if ESLint is available via npx or global install."""
        return shutil.which("eslint") is not None or shutil.which("eslint.cmd") is not None

    @staticmethod
    def analyze_file(filepath: str) -> Dict[str, Any]:
        """Runs ESLint on a given JS file path."""
        if not os.path.exists(filepath):
            return {"language": "JavaScript", "error": f"File not found: {filepath}", "issues": []}

        # Prefer using local npx if eslint isn't installed globally but is available locally
        eslint_cmd = "eslint.cmd" if os.name == 'nt' else "eslint"
        
        try:
            # Run ESLint with JSON output format
            result = subprocess.run(
                [eslint_cmd, "-f", "json", filepath],
                capture_output=True,
                text=True
            )
            
            if not result.stdout.strip():
                return {"language": "JavaScript", "issues": []}
                
            eslint_output = json.loads(result.stdout)
            
            normalized_issues = []
            for file_report in eslint_output:
                for issue in file_report.get("messages", []):
                    severity_map = {1: "warning", 2: "error"}
                    normalized_issues.append({
                        "line": issue.get("line", 0),
                        "rule": issue.get("ruleId", "unknown"),
                        "message": issue.get("message", ""),
                        "severity": severity_map.get(issue.get("severity"), "unknown"),
                        "tool": "eslint"
                    })
                    
            return {
                "language": "JavaScript",
                "issues": normalized_issues
            }

        except json.JSONDecodeError as e:
            return {"language": "JavaScript", "error": f"Failed to parse ESLint output: {str(e)}\nStdout: {result.stdout}", "issues": []}
        except FileNotFoundError:
             return {"language": "JavaScript", "error": "ESLint not found. Please install it.", "issues": []}
        except Exception as e:
            return {"language": "JavaScript", "error": f"ESLint execution failed: {str(e)}", "issues": []}

    @staticmethod
    def analyze_code(code: str) -> Dict[str, Any]:
        """Runs ESLint on a raw code snippet by using a temporary file."""
        # Create temp file in current directory so eslint can find the local config
        fd, temp_path = tempfile.mkstemp(suffix=".js", dir=".")
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(code)
            return ESLintAnalyzer.analyze_file(temp_path)
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

if __name__ == "__main__":
    if not ESLintAnalyzer.is_available():
        print("ESLint is NOT installed or not in PATH. Please install it first.")
        exit(1)
        
    problematic_js = """
var x = 10;
if (x == 10) {
    console.log("hello")
}
"""
    print("Testing ESLintAnalyzer with problematic code snippet...")
    result = ESLintAnalyzer.analyze_code(problematic_js)
    print(json.dumps(result, indent=4))
