import json
import subprocess
import tempfile
import os
import shutil
from typing import Dict, Any

class PMDAnalyzer:
    """
    Runs PMD on Java source code or files and normalizes the output.
    """
    
    @staticmethod
    def is_available() -> bool:
        """Check if PMD is available in the system PATH."""
        return shutil.which("pmd") is not None or shutil.which("pmd.bat") is not None

    @staticmethod
    def analyze_file(filepath: str) -> Dict[str, Any]:
        """Runs PMD on a given Java file path."""
        if not os.path.exists(filepath):
            return {"language": "Java", "error": f"File not found: {filepath}", "issues": []}

        pmd_cmd = "pmd.bat" if os.name == 'nt' else "pmd"
        
        try:
            # Run PMD with JSON output format
            # PMD check syntax: pmd check -d <file> -R rulesets/java/quickstart.xml -f json
            result = subprocess.run(
                [pmd_cmd, "check", "-d", filepath, "-R", "category/java/errorprone.xml,category/java/bestpractices.xml", "-f", "json"],
                capture_output=True,
                text=True
            )
            
            # PMD exits with non-zero if issues are found, which is expected.
            if not result.stdout.strip():
                return {"language": "Java", "issues": []}
                
            pmd_output = json.loads(result.stdout)
            
            normalized_issues = []
            files = pmd_output.get("files", [])
            for file_report in files:
                for issue in file_report.get("violations", []):
                    normalized_issues.append({
                        "line": issue.get("beginline", 0),
                        "rule": issue.get("rule", ""),
                        "message": issue.get("description", "").strip(),
                        "severity": str(issue.get("priority", "unknown")),
                        "tool": "pmd"
                    })
                    
            return {
                "language": "Java",
                "issues": normalized_issues
            }

        except json.JSONDecodeError as e:
            return {"language": "Java", "error": f"Failed to parse PMD output: {str(e)}\nStdout: {result.stdout}", "issues": []}
        except FileNotFoundError:
             return {"language": "Java", "error": "PMD not found in PATH. Please install PMD.", "issues": []}
        except Exception as e:
            return {"language": "Java", "error": f"PMD execution failed: {str(e)}", "issues": []}

    @staticmethod
    def analyze_code(code: str) -> Dict[str, Any]:
        """Runs PMD on a raw code snippet by using a temporary file."""
        fd, temp_path = tempfile.mkstemp(suffix=".java")
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(code)
            return PMDAnalyzer.analyze_file(temp_path)
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

if __name__ == "__main__":
    if not PMDAnalyzer.is_available():
        print("PMD is NOT installed or not in PATH. Please install it first.")
        exit(1)
        
    problematic_java = """
public class Test {
    public static void main(String[] args) {
        String password = "hardcoded_password"; // Error prone
        try {
            int a = 1 / 0;
        } catch (Exception e) {
            // empty catch block
        }
    }
}
"""
    print("Testing PMDAnalyzer with problematic code snippet...")
    result = PMDAnalyzer.analyze_code(problematic_java)
    print(json.dumps(result, indent=4))
