import os
from typing import List, Dict, Any

import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.embeddings.codebert_embeddings import CodeBERTEmbeddings
from src.retrieval.faiss_store import FAISSStore

class Retriever:
    """
    Retrieves the most semantically similar code chunks from the FAISS index
    given a source code query.
    """
    def __init__(self, embedder: CodeBERTEmbeddings = None, store: FAISSStore = None):
        self.embedder = embedder if embedder else CodeBERTEmbeddings()
        self.store = store if store else FAISSStore("vectorstore")
        
        # Load store if it has no index
        if self.store.index is None:
            self.store.load()

    def retrieve(self, query_code: str, top_k: int = 5, language: str = None) -> List[Dict[str, Any]]:
        """
        Retrieves top-k similar chunks for the query code.
        Optional language filtering.
        """
        if not query_code.strip():
            raise ValueError("Query code cannot be empty.")
            
        if self.store.index is None or self.store.index.ntotal == 0:
            raise ValueError("FAISS index is empty or not loaded.")
            
        # Generate embedding for the query
        query_embedding = self.embedder.generate_embeddings([query_code])
        
        # Search the store
        results = self.store.search(query_embedding, top_k=top_k, language=language)
        
        return results
