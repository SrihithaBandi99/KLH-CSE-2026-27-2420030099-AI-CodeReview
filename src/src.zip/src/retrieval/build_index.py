import os
import argparse
from typing import List, Dict, Any

import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.chunking.code_chunker import CodeChunker
from src.embeddings.codebert_embeddings import CodeBERTEmbeddings
from src.retrieval.faiss_store import FAISSStore
from src.language_detector import LanguageDetector

def load_corpus(corpus_dir: str) -> List[Dict[str, Any]]:
    """Loads source code files from the corpus directory."""
    files_data = []
    if not os.path.exists(corpus_dir):
        print(f"Corpus directory {corpus_dir} not found.")
        return files_data
        
    for root, _, files in os.walk(corpus_dir):
        for file in files:
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    code = f.read()
                
                lang = LanguageDetector.detect_language(code, filepath)
                if lang != "Unknown":
                    files_data.append({
                        "source": filepath,
                        "code": code,
                        "language": lang
                    })
            except Exception as e:
                print(f"Error reading {filepath}: {e}")
                
    return files_data

def build_index():
    print("============================================================")
    print("PHASE 4: BUILDING FAISS INDEX")
    print("============================================================")
    
    corpus_dir = "data/code_corpus"
    files_data = load_corpus(corpus_dir)
    print(f"Number of source files: {len(files_data)}")
    
    if not files_data:
        print("No files to process. Create data/code_corpus with sample files.")
        return

    # Chunking
    all_chunks = []
    for file_data in files_data:
        chunks = CodeChunker.chunk_code(file_data["code"], file_data["language"], file_data["source"])
        all_chunks.extend(chunks)
        
    print(f"Number of chunks: {len(all_chunks)}")
    
    if not all_chunks:
        print("No chunks generated.")
        return

    # Embeddings
    print("\nLoading CodeBERT model...")
    embedder = CodeBERTEmbeddings(batch_size=8)
    print(f"Embedding dimension: {embedder.dimension}")
    
    codes_to_embed = [chunk["code"] for chunk in all_chunks]
    print(f"\nGenerating embeddings for {len(codes_to_embed)} chunks...")
    embeddings = embedder.generate_embeddings(codes_to_embed)
    
    # FAISS Store
    print("\nBuilding FAISS index...")
    store = FAISSStore("vectorstore")
    store.initialize_index(embedder.dimension)
    store.add_embeddings(embeddings, all_chunks)
    
    print(f"Number of vectors: {store.index.ntotal}")
    store.save()
    print("Build index complete!")

if __name__ == "__main__":
    build_index()
