import os
import json
import faiss
import numpy as np
from typing import List, Dict, Any

class FAISSStore:
    """
    Manages the FAISS index and corresponding metadata for code retrieval.
    Uses IndexFlatIP since embeddings are normalized (Cosine Similarity).
    """
    
    def __init__(self, index_dir: str = "vectorstore"):
        self.index_dir = index_dir
        self.index_path = os.path.join(index_dir, "code_index.faiss")
        self.metadata_path = os.path.join(index_dir, "metadata.json")
        
        self.index = None
        self.metadata: List[Dict[str, Any]] = []
        
        # Create directory if it doesn't exist
        os.makedirs(self.index_dir, exist_ok=True)

    def initialize_index(self, dimension: int):
        """Creates a new empty IndexFlatIP."""
        self.index = faiss.IndexFlatIP(dimension)
        self.metadata = []
        print(f"Initialized new FAISS index with dimension {dimension}")

    def add_embeddings(self, embeddings: np.ndarray, metadatas: List[Dict[str, Any]]):
        """Adds normalized embeddings and their metadata to the store."""
        if self.index is None:
            raise ValueError("Index not initialized. Call initialize_index or load first.")
        
        if len(embeddings) != len(metadatas):
            raise ValueError(f"Mismatch: {len(embeddings)} embeddings vs {len(metadatas)} metadatas.")
            
        if len(embeddings) > 0:
            self.index.add(embeddings)
            self.metadata.extend(metadatas)

    def save(self):
        """Saves the FAISS index and metadata to disk."""
        if self.index is None:
            raise ValueError("No index to save.")
            
        faiss.write_index(self.index, self.index_path)
        
        with open(self.metadata_path, 'w', encoding='utf-8') as f:
            json.dump(self.metadata, f, indent=4)
            
        print(f"Saved FAISS index to {self.index_path}")
        print(f"Saved metadata to {self.metadata_path}")

    def load(self):
        """Loads the FAISS index and metadata from disk."""
        if not os.path.exists(self.index_path) or not os.path.exists(self.metadata_path):
            raise FileNotFoundError(f"Index or metadata not found in {self.index_dir}")
            
        self.index = faiss.read_index(self.index_path)
        
        with open(self.metadata_path, 'r', encoding='utf-8') as f:
            self.metadata = json.load(f)
            
        print(f"Loaded FAISS index with {self.index.ntotal} vectors.")

    def search(self, query_embedding: np.ndarray, top_k: int = 5, language: str = None) -> List[Dict[str, Any]]:
        """
        Searches the index for the top-k most similar chunks.
        Optionally filters by language.
        """
        if self.index is None:
            raise ValueError("Index not loaded.")
            
        if query_embedding.shape[0] != 1:
            raise ValueError("Query embedding should be a single vector (1, D)")
            
        # If filtering, we retrieve more, then filter, then truncate to top_k
        fetch_k = top_k * 5 if language else top_k
        fetch_k = min(fetch_k, self.index.ntotal)
        
        if fetch_k == 0:
            return []
            
        scores, indices = self.index.search(query_embedding, fetch_k)
        
        results = []
        for i, idx in enumerate(indices[0]):
            if idx == -1: # Not enough results
                continue
                
            meta = self.metadata[idx].copy()
            meta["score"] = float(scores[0][i])
            
            if language and meta.get("language") != language:
                continue
                
            results.append(meta)
            
            if len(results) >= top_k:
                break
                
        return results
