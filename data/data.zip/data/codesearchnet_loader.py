import json
from pathlib import Path


def load_codesearchnet(jsonl_path, max_records=1000):
    records = []

    with open(jsonl_path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):

            if i >= max_records:
                break

            data = json.loads(line)

            code = data.get("code", "")
            language = data.get("language", "")
            func_name = data.get("func_name", "")
            repo = data.get("repo", "")

            if code.strip():
                records.append({
                    "code": code,
                    "language": language,
                    "func_name": func_name,
                    "repo": repo
                })

    return records