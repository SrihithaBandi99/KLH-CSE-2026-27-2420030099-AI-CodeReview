def calculate_average(numbers):
    if not numbers:
        return 0
    return sum(numbers) / len(numbers)

def authenticate_user(username, password):
    # Dummy authentication logic
    if username == "admin" and password == "secret123":
        return True
    return False

def write_to_file(filepath, content):
    with open(filepath, 'w') as f:
        f.write(content)
