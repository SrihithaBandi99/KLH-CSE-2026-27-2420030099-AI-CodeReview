public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }
    
    public int subtract(int a, int b) {
        return a - b;
    }
}

public class UserValidation {
    public boolean isValidUser(String username, String token) {
        if (username != null && token.equals("valid_token")) {
            return true;
        }
        return false;
    }
}
